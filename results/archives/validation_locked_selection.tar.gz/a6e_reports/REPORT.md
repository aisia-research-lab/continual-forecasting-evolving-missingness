# A-6E Validation-Locked GPU Audit

{
  "complete": true,
  "jobs": 120,
  "planned_jobs": 120,
  "selection_groups": 20,
  "selection_counts": {
    "A6C-Clip1": 10,
    "OMPB-Delayed": 8,
    "Frozen": 2
  },
  "released_events_audited": 41980,
  "positive_conditions_vs_delayed": 12,
  "positive_conditions_vs_frozen": 24,
  "significant_t_positive_vs_delayed": 11,
  "significant_signflip_vs_delayed": 0,
  "limitations": [
    "last-20-percent test calendar has been examined in A6D",
    "new seeds provide repeatability evidence but no new untouched-time test",
    "A6E is validation-selected whole-arm switch, not per-origin online gating",
    "adaptive selection incurs extra validation compute"
  ]
}
