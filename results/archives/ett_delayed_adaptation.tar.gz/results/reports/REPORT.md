# Paper A — GPU execution report

Completed **120/120 matched-information jobs**, **18/18 official-native jobs**.
Excluded **1 smoke jobs** from statistical reports.
Validated **50920 strictly released label events**.

## Interpretation rules

- Native OMPB feedback and strict physical delayed feedback are **different protocols**.
- Development gains do not imply statistical or practical superiority.
- Confidence intervals use independent seed-level paired errors; forecast origins overlap.
- Feature-augmented heads have added trainable parameters. Mask-only capacity control is reported.
- No claim of Neurocomputing submission readiness is made by this report.

## Output files

- `matched_per_seed.csv`, `matched_aggregate.csv`: descriptive performance.
- `paired_tests.csv`: seed-paired 95% intervals and Holm correction.
- `native_official_metrics.csv`: source-author protocol and full-window updates.
- `AUDIT.json`: completion and strict release checks.
